#!/usr/bin/env ruby
# by Andronik Ordian

def edit_distance(a, b)
  # write your code here	
  0
end

if __FILE__ == $0
  a, b = gets, gets
  puts edit_distance(a, b)
end
